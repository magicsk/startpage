# magic's minimal startpage
This is a simple, minimal startpage that meet my needs.

![Fullscreen view](https://files.magicsk.eu/file/startpage.png?time=1630703139237)

It's a fork of https://gitlab.com/wolfiy/wlfys-minimal-startpage.
